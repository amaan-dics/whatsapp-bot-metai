{
    'name': 'WhatsApp Order Integration',
    'version': '15.0.1.0',
    'category': 'Sales',
    'summary': 'Native WhatsApp Meta API Integration for Odoo',
    'depends': ['sale_management', 'website', 'payment', 'website_sale', 'stock', 'crm', 'payment_stripe'],
    'data': [
        'security/ir.model.access.csv',
        'views/res_config_settings_views.xml',

    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}