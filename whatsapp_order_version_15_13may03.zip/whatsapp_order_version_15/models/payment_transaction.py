import logging
from odoo import models, api
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    @api.model
    def create(self, vals):
        """Block duplicate payment attempts for already confirmed orders."""
        if vals.get('sale_order_ids'):
            order_ids = []
            for command in vals['sale_order_ids']:
                if len(command) == 3 and command[0] == 6:
                    order_ids.extend(command[2])
                elif len(command) == 2 and command[0] == 4:
                    order_ids.append(command[1])

            if order_ids:
                orders = self.env['sale.order'].sudo().browse(order_ids)
                for order in orders:
                    if order.state in ['sale', 'done']:
                        raise ValidationError(
                            f"Order {order.name} has already been paid and confirmed."
                        )

        return super().create(vals)

    def write(self, vals):
        res = super().write(vals)
        new_state = vals.get('state')

        if new_state:
            _logger.info(f"🔄 WhatsApp Bot: Payment state changed to: {new_state}")

            for tx in self:
                if not tx.sale_order_ids:
                    continue

                for order in tx.sale_order_ids:
                    phone = order.partner_id.phone
                    if not phone:
                        continue

                    session = self.env['whatsapp.session'].sudo().search([('phone', '=', phone)], limit=1)
                    if not session:
                        continue

                    # SUCCESS LOGIC
                    if new_state in ['done', 'pending']:
                        print(f"\n========== 🧾 PROCESSING SUCCESS FOR {order.name} ==========")

                        # A. Lock the Order
                        if order.state in ['draft', 'sent']:
                            order.sudo().action_confirm()

                        invoice_pdf_content = None
                        invoice_filename = "Invoice.pdf"

                        try:
                            # B. Create and Post Invoice
                            invoices = order.sudo()._create_invoices()
                            if invoices:
                                invoices.sudo().action_post()
                                print(f"✅ Invoice Posted: {invoices[0].name}")

                                # C. Instant Payment Registration (Forces "Paid" status)
                                for current_tx in self:
                                    current_tx.invoice_ids = [(6, 0, invoices.ids)]
                                    journal = current_tx.acquirer_id.journal_id or self.env[
                                        'account.journal'].sudo().search([('type', 'in', ['bank', 'cash'])], limit=1)

                                    if journal:
                                        # Use the Register Payment wizard to bypass background delays
                                        payment_wizard = self.env['account.payment.register'].with_context(
                                            active_model='account.move',
                                            active_ids=invoices.ids
                                        ).sudo().create({
                                            'amount': current_tx.amount,
                                            'journal_id': journal.id,
                                        })
                                        payment_wizard._create_payments()
                                        print("✅ Payment Registered Locally")

                                # D. Save & Generate PDF
                                self.env.cr.flush()
                                invoices.invalidate_cache()

                                # Use 'report_invoice_with_payments' to ensure the PAID ribbon appears
                                report = self.env.ref('account.account_invoices')
                                invoice_pdf_content, _ = report.with_user(1)._render_qweb_pdf(invoices.ids)
                                invoice_filename = f"{invoices[0].name.replace('/', '_')}.pdf"
                                print(f"✅ PDF Generated: {len(invoice_pdf_content)} bytes")

                        except Exception as e:
                            print(f"❌ INVOICE ERROR: {e}")

                        # E. Send Text Message
                        session.send_text(f"✅ *Payment Successful!*\n\nYour order {order.name} is confirmed! 📦")

                        # F. Send PDF
                        if invoice_pdf_content:
                            session.send_pdf(
                                pdf_content=invoice_pdf_content,
                                filename=invoice_filename,
                                caption="🧾 Here is your paid receipt."
                            )
                        print("============================================================\n")

                    # FAILURE LOGIC
                    elif new_state in ['error', 'cancel']:
                        session.send_text(
                            f"❌ *Payment Failed*\nOrder {order.name} could not be processed. Please try again.")

        return res