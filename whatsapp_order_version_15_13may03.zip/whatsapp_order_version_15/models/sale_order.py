from odoo import models, api
from urllib.parse import urlparse
import logging

_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    @api.model
    def create_from_whatsapp(self, phone, cart, customer_name=None, customer_email=None, customer_address=None):
        if not phone or not cart:
            return {"error": "Missing phone or cart items"}

        # ---------------------------------------------------------
        # ADDRESS PARSING HELPER
        # ---------------------------------------------------------
        def parse_address_to_dict(raw_address):
            vals = {}
            parts = [p.strip() for p in raw_address.split(',')]

            # If they followed the comma format (at least 4 parts)
            if len(parts) >= 4:
                vals['street'] = parts[0]  # House Number
                vals['street2'] = parts[1]  # Street Name
                vals['city'] = parts[2]  # City
                vals['zip'] = parts[3]  # Zip Code

                # If they included the country
                if len(parts) >= 5:
                    country = self.env['res.country'].search([('name', 'ilike', parts[4])], limit=1)
                    if country:
                        vals['country_id'] = country.id
            else:
                # Fallback: They didn't use commas, shove it in street 1 safely
                vals['street'] = raw_address

            return vals

        # ---------------------------------------------------------
        # CUSTOMER CREATION / UPDATE
        # ---------------------------------------------------------
        partner = self.env['res.partner'].search([('phone', '=', phone)], limit=1)

        if not partner:
            # Create NEW customer
            partner_vals = {'name': customer_name or phone, 'phone': phone}
            if customer_email:
                partner_vals['email'] = customer_email

            # If new customer, they definitely typed a raw address
            if customer_address and not customer_address.startswith("ID:"):
                partner_vals.update(parse_address_to_dict(customer_address))

            partner = self.env['res.partner'].create(partner_vals)
        else:
            # Update EXISTING customer email
            if customer_email and not partner.email:
                partner.write({'email': customer_email})

        # ---------------------------------------------------------
        # SHIPPING & DELIVERY LOGIC
        # ---------------------------------------------------------
        shipping_id = partner.id  # Default to main partner

        if customer_address:
            if customer_address.startswith("ID:"):
                # They selected an existing address from the interactive list
                shipping_id = int(customer_address.split(":")[1])
            else:
                # They typed a brand NEW address. Let's create a Delivery Contact!
                addr_vals = parse_address_to_dict(customer_address)

                # If their main profile has no address, update it directly
                if not partner.street:
                    partner.write(addr_vals)
                else:
                    # Create a child contact specifically for delivery
                    addr_vals.update({
                        'parent_id': partner.id,
                        'type': 'delivery',
                        'name': f"{partner.name} (Delivery)"
                    })
                    new_delivery = self.env['res.partner'].create(addr_vals)
                    shipping_id = new_delivery.id

        # Find or Create the WhatsApp Source Tag
        whatsapp_source = self.env['utm.source'].search([('name', '=', 'WhatsApp Bot')], limit=1)
        if not whatsapp_source:
            whatsapp_source = self.env['utm.source'].create({'name': 'WhatsApp Bot'})

        # Build Order Lines
        order_lines = []
        for item in cart:
            product = None
            if item.get('product_id'):
                product = self.env['product.product'].browse(item['product_id']).exists()
            if not product:
                product = self.env['product.product'].search([('name', '=', item.get('product_name'))], limit=1)

            if product:
                qty = item.get('quantity', 1)
                price_unit = item.get('price', product.list_price)
                order_lines.append((0, 0, {
                    'product_id': product.id,
                    'product_uom_qty': qty,
                    'price_unit': price_unit,
                }))

        if not order_lines:
            return {"error": "No valid products found."}

            # Create the Order
        order = self.create({
                'partner_id': partner.id,
                'partner_shipping_id': shipping_id,
                'order_line': order_lines,
                'source_id': whatsapp_source.id
            })

            # ---------------------------------------------------------
            # GENERATE WIZARD LINK (Bypasses strict portal rules)
            # ---------------------------------------------------------
        wizard = self.env['payment.link.wizard'].with_context(active_id=order.id, active_model='sale.order').create(
                {})

        public_url = self.env['ir.config_parameter'].sudo().get_param('whatsapp_order.public_url')
        payment_link = wizard.link

        if public_url and payment_link:
                parsed = urlparse(payment_link)
                payment_link = public_url.rstrip('/') + parsed.path + (f"?{parsed.query}" if parsed.query else "")

        return {"order_id": order.id, "payment_link": payment_link or "NO_LINK"}