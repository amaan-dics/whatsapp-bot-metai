from odoo import models, fields, api
import requests
import json
import logging

_logger = logging.getLogger(__name__)


class WhatsappSession(models.Model):
    _name = 'whatsapp.session'
    _description = 'WhatsApp Bot Session'

    phone = fields.Char(required=True, index=True)
    step = fields.Char(default='start')
    cart_data = fields.Text(default='[]')
    customer_name = fields.Char()
    customer_email = fields.Char()
    customer_address = fields.Text()
    selected_variant_id = fields.Many2one('product.product')

    def _get_meta_url_and_headers(self):
        ICP = self.env['ir.config_parameter'].sudo()
        token = ICP.get_param('whatsapp_order.meta_token')
        phone_id = ICP.get_param('whatsapp_order.phone_id')
        url = f"https://graph.facebook.com/v19.0/{phone_id}/messages"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        return url, headers

    def _send_payload(self, payload):
        url, headers = self._get_meta_url_and_headers()
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=10)
            if response.status_code not in [200, 201]:
                print(f"\n========== META REJECTED MESSAGE ({response.status_code}) ==========")
                print(response.text)
                print("========================================================\n")
                _logger.error(f"[META API REJECTED] {response.text}")
            else:
                _logger.info("[META API SUCCESS] Message sent to phone.")
        except Exception as e:
            _logger.error(f"[META HTTP FAILED] {e}")

    def send_text(self, text):
        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "text",
            "text": {"body": text}
        }
        self._send_payload(payload)

    def send_pdf(self, pdf_content, filename, caption=""):
        """Uploads a PDF binary to Meta and sends it to the customer as a document."""
        print(f"\n========== 📤 INITIATING PDF UPLOAD TO META ==========")
        print(f"File Name: {filename}")
        print(f"File Size: {len(pdf_content)} bytes")

        ICP = self.env['ir.config_parameter'].sudo()
        token = ICP.get_param('whatsapp_order.meta_token')
        phone_id = ICP.get_param('whatsapp_order.phone_id')

        upload_url = f"https://graph.facebook.com/v19.0/{phone_id}/media"
        headers = {"Authorization": f"Bearer {token}"}

        data = {
            "messaging_product": "whatsapp"
        }

        files = {
            "file": (filename, pdf_content, "application/pdf")
        }

        try:
            print("Sending file to Meta Media API...")
            upload_response = requests.post(upload_url, headers=headers, data=data, files=files, timeout=15)
            print(f"Meta Response Code: {upload_response.status_code}")
            print(f"Meta Response Body: {upload_response.text}")

            if upload_response.status_code not in [200, 201]:
                print("❌ FAILED: Meta rejected the upload.")
                return False

            media_id = upload_response.json().get('id')
            print(f"✅ Success! Media ID received: {media_id}")
            print("======================================================\n")

        except Exception as e:
            print(f"❌ CRASH DURING UPLOAD: {e}")
            _logger.error(f"[META UPLOAD FAILED] {e}")
            return False

        # 2. Send Document via Media ID
        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "document",
            "document": {
                "id": media_id,
                "filename": filename,
                "caption": caption
            }
        }
        self._send_payload(payload)
        return True
    
    def send_interactive_list(self, products):
        rows = []
        for p in products[:10]:
            price = p.get('list_price', 0)
            rows.append({
                "id": str(p["id"])[:200],
                "title": str(p["name"])[:24],
                "description": f"Price: {price}"[:72]
            })

        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "interactive",
            "interactive": {
                "type": "list",
                "header": {"type": "text", "text": "🛍️ Our Catalog"},
                "body": {"text": "Tap the button below to browse our products."},
                "footer": {"text": "Select a product to continue"},
                "action": {
                    "button": "View Products",
                    "sections": [{"title": "Available Items", "rows": rows}]
                }
            }
        }
        self._send_payload(payload)

    def send_buttons(self, text, buttons):
        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": text},
                "action": {
                    "buttons": [
                        {"type": "reply", "reply": {"id": b["id"][:250], "title": b["title"][:20]}}
                        for b in buttons[:3]
                    ]
                }
            }
        }
        self._send_payload(payload)

    def send_category_list(self, categories):
        rows = []
        for c in categories[:10]:
            count = self.env['product.template'].sudo().search_count([('public_categ_ids', 'in', [c['id']])])
            rows.append({
                "id": f"cat_{c['id']}"[:200],
                "title": str(c["name"])[:24],
                "description": f"Browse {count} items" if count > 0 else "View collection"
            })

        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "interactive",
            "interactive": {
                "type": "list",
                "header": {"type": "text", "text": "🗂️ Departments"},
                "body": {"text": "Please select a category to browse our catalog:"},
                "footer": {"text": "Select an option below"},
                "action": {
                    "button": "View Categories",
                    "sections": [{"title": "Our Categories", "rows": rows}]
                }
            }
        }
        self._send_payload(payload)

    def ask_for_quantity(self, product_name):
        self.send_text(
            f"🔢 How many units of *{product_name}* do you need?\n\n"
            f"_(Please type a number, for example: 2)_"
        )

    def send_variant_list(self, variants, template_name):
        rows = []
        for v in variants[:10]:
            price = v.get('list_price', 0)
            full_name = str(v["name"])

            if "(" in full_name and ")" in full_name:
                variant_attr = full_name.split("(")[-1].split(")")[0]
            else:
                variant_attr = full_name.replace(template_name, "").strip() or full_name

            rows.append({
                "id": str(v["id"])[:200],
                "title": variant_attr[:24],
                "description": f"Price: {price} | {full_name}"[:72]
            })

        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "interactive",
            "interactive": {
                "type": "list",
                "header": {"type": "text", "text": "🔀 Select Variant"},
                "body": {
                    "text": f"*{template_name[:40]}* has multiple options. Please choose your preferred variant from the list below:"},
                "footer": {"text": "Tap to select"},
                "action": {
                    "button": "Choose Variant",
                    "sections": [{"title": "Available Options", "rows": rows}]
                }
            }
        }
        self._send_payload(payload)