from odoo import models, api
from urllib.parse import urlparse
import logging

_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    @api.model
    def create_from_whatsapp(self, phone, cart, customer_name=None, customer_email=None):
        if not phone or not cart:
            return {"error": "Missing phone or cart items"}

        partner = self.env['res.partner'].search([('phone', '=', phone)], limit=1)
        if not partner:
            partner_vals = {'name': customer_name or phone, 'phone': phone}
            if customer_email: partner_vals['email'] = customer_email
            partner = self.env['res.partner'].create(partner_vals)
        else:
            if customer_email and not partner.email:
                partner.email = customer_email

        order_lines = []
        for item in cart:
            product = self.env['product.product'].search([('name', '=', item.get('product_name'))], limit=1)
            if product:
                order_lines.append((0, 0, {'product_id': product.id, 'product_uom_qty': item.get('quantity', 1)}))

        if not order_lines:
            return {"error": "No valid products found."}

        order = self.create({'partner_id': partner.id, 'order_line': order_lines})
        order.action_confirm()

        wizard = self.env['payment.link.wizard'].with_context(active_id=order.id, active_model='sale.order').create({})

        # Replace localhost with your configured ngrok URL
        public_url = self.env['ir.config_parameter'].sudo().get_param('whatsapp_order.public_url')
        payment_link = wizard.link
        if public_url and payment_link:
            parsed = urlparse(payment_link)
            payment_link = public_url.rstrip('/') + parsed.path + (f"?{parsed.query}" if parsed.query else "")

        return {"order_id": order.id, "payment_link": payment_link or "NO_LINK"}