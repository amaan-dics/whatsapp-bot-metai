from odoo import models, fields

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    whatsapp_meta_token = fields.Char(string="Meta Access Token", config_parameter='whatsapp_order.meta_token')
    whatsapp_phone_id = fields.Char(string="Meta Phone ID", config_parameter='whatsapp_order.phone_id')
    whatsapp_verify_token = fields.Char(string="Webhook Verify Token", config_parameter='whatsapp_order.verify_token', default="my_secret_token_123")
    whatsapp_public_url = fields.Char(string="Public URL (Ngrok)", config_parameter='whatsapp_order.public_url', help="e.g., https://your-ngrok.app")

    whatsapp_contact_url = fields.Char(string="Contact Us Link", config_parameter='whatsapp_order.contact_url',
                                       help="Full URL to send to customers, e.g., https://mywebsite.com/contact")