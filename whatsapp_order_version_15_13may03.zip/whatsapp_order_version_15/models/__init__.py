from . import res_config_settings
from . import whatsapp_session
from . import sale_order
from . import payment_transaction