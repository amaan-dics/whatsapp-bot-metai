from odoo import models, fields, api
import requests
import json
import logging

_logger = logging.getLogger(__name__)

class WhatsappSession(models.Model):
    _name = 'whatsapp.session'
    _description = 'WhatsApp Bot Session'

    phone = fields.Char(required=True, index=True)
    step = fields.Char(default='start')
    cart_data = fields.Text(default='[]') # Stores JSON string of cart array
    customer_name = fields.Char()
    customer_email = fields.Char()

    def _get_meta_url_and_headers(self):
        ICP = self.env['ir.config_parameter'].sudo()
        token = ICP.get_param('whatsapp_order.meta_token')
        phone_id = ICP.get_param('whatsapp_order.phone_id')
        url = f"https://graph.facebook.com/v19.0/{phone_id}/messages"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        return url, headers

    def send_text(self, text):
        url, headers = self._get_meta_url_and_headers()
        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "text",
            "text": {"body": text}
        }
        try:
            requests.post(url, headers=headers, json=payload, timeout=10)
        except Exception as e:
            _logger.error(f"[META SEND ERROR] {e}")

    def send_interactive_list(self, products):
        url, headers = self._get_meta_url_and_headers()
        rows = []
        for p in products[:10]:
            price = p.get('list_price', 0)
            rows.append({
                "id": str(p["id"]),
                "title": str(p["name"])[:24],
                "description": f"Price: {price}"[:72]
            })

        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "interactive",
            "interactive": {
                "type": "list",
                "header": {"type": "text", "text": "🛍️ Our Catalog"},
                "body": {"text": "Tap the button below to browse our products."},
                "footer": {"text": "Select a product to continue"},
                "action": {
                    "button": "View Products",
                    "sections": [{"title": "Available Items", "rows": rows}]
                }
            }
        }
        requests.post(url, headers=headers, json=payload, timeout=10)

    def send_buttons(self, text, buttons):
        url, headers = self._get_meta_url_and_headers()
        payload = {
            "messaging_product": "whatsapp",
            "to": self.phone,
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {"text": text},
                "action": {
                    "buttons": [
                        {"type": "reply", "reply": {"id": b["id"], "title": b["title"][:20]}}
                        for b in buttons[:3]
                    ]
                }
            }
        }
        requests.post(url, headers=headers, json=payload, timeout=10)