import json
import logging
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class WhatsAppController(http.Controller):

    def _add_to_cart(self, cart, product):
        """Add product to cart or increment quantity if already present"""
        existing = next((item for item in cart if item.get('product_id') == product['id']), None)
        if existing:
            existing['quantity'] += 1
        else:
            cart.append({
                'product_id': product['id'],
                'product_name': product['name'],
                'quantity': 1,
                'price': product.get('list_price', 0.0),
            })
        return cart

    def _add_to_cart_with_qty(self, cart, product, qty):
        """Add product to cart with a specific quantity"""
        # Note: 'product' here is an Odoo recordset, not a dictionary
        existing = next((item for item in cart if item.get('product_id') == product.id), None)
        if existing:
            existing['quantity'] += qty
        else:
            cart.append({
                'product_id': product.id,
                'product_name': product.display_name,  # Uses display_name to show variant attributes like (Red, Large)
                'quantity': qty,
                'price': product.list_price,
            })
        return cart

    def _format_cart(self, cart, env):
        """Return formatted cart text with professional receipt layout, including dynamic taxes"""
        if not cart:
            return "_(empty)_", 0.0

        lines = []
        total_untaxed = 0.0
        total_tax = 0.0
        total_amount = 0.0
        currency = env.company.currency_id.symbol or '₹'

        # 1. Professional Header
        lines.append("🛍️ *YOUR SHOPPING CART*")
        lines.append("━━━━━━━━━━━━━━━━━━━━━")

        # 2. Structured Item List
        for item in cart:
            qty = item.get('quantity', 1)
            price = item.get('price', 0.0)

            # Get the actual Odoo product record to check for taxes
            product = None
            if item.get('product_id'):
                product = env['product.product'].sudo().browse(item['product_id'])
                if not price and product:
                    price = product.list_price

            # Calculate precise taxes using Odoo's native engine
            if product and product.taxes_id:
                tax_res = product.taxes_id.sudo().compute_all(
                    price, env.company.currency_id, qty, product=product
                )
                subtotal_untaxed = tax_res['total_excluded']
                subtotal_tax = tax_res['total_included'] - tax_res['total_excluded']
                subtotal_included = tax_res['total_included']
                tax_amount = product.taxes_id.amount
            else:
                # No taxes applied to this product
                subtotal_untaxed = price * qty
                subtotal_tax = 0.0
                subtotal_included = price * qty

            # Add to running totals
            total_untaxed += subtotal_untaxed
            total_tax += subtotal_tax
            total_amount += subtotal_included

            # Format the item line
            lines.append(f"📦 *{item['product_name']}*")

            lines.append(f"   └  {qty} x {currency}{price:.2f} = *{currency}{subtotal_included:.2f}*")
            lines.append("")  # Blank line for breathing room

        # 3. Professional Footer
        lines.append("━━━━━━━━━━━━━━━━━━━━━")

        # 4. Conditional Tax Display
        if total_tax > 0:
            lines.append(f"💵 Subtotal: {currency}{total_untaxed:.2f}")
            lines.append(f"🏛️ Tax: {currency}{total_tax:.2f}")

        lines.append(f"🧾 *TOTAL DUE:* {currency}{total_amount:.2f}")

        return "\n".join(lines), total_amount
    # new
    def _send_address_list(self, session, rows):
        """Builds and sends an interactive list of saved delivery addresses."""
        payload = {
            "messaging_product": "whatsapp",
            "to": session.phone,
            "type": "interactive",
            "interactive": {
                "type": "list",
                "header": {"type": "text", "text": "📍 Delivery Address"},
                "body": {"text": "Please select where you want this order delivered, or add a new address:"},
                "footer": {"text": "Tap to select"},
                "action": {
                    "button": "Select Address",
                    "sections": [{"title": "Saved Addresses", "rows": rows}]
                }
            }
        }
        session._send_payload(payload)

    def _handle_checkout_flow(self, session, env, cart, phone):
        """Centralized checkout logic to check for emails and saved addresses."""
        if not cart:
            session.send_text("🛒 Your cart is empty.")
            return

        if not session.customer_email:
            session.sudo().write({'step': 'email'})
            session.send_text("Great! What is your email address for the receipt? (Or reply 'skip')")
            return

        # Check for saved addresses
        partner = env['res.partner'].sudo().search([('phone', '=', phone)], limit=1)
        addresses = []
        if partner:
            # Find child 'delivery' addresses
            addresses = env['res.partner'].sudo().search([
                ('parent_id', '=', partner.id),
                ('type', '=', 'delivery')
            ])
            # Include the main partner's address if they have one
            if partner.street:
                addresses = partner | addresses

        if addresses:
            session.sudo().write({'step': 'select_address'})
            rows = []
            for addr in addresses[:9]:  # Meta allows max 10 rows
                city = addr.city or ''
                street = addr.street or 'Saved Address'
                title = f"{addr.name} ({addr.type.title()})" if addr.type == 'delivery' else "Home/Main Address"
                rows.append({
                    "id": f"addr_{addr.id}",
                    "title": title[:24],
                    "description": f"{street}, {city}"[:72]
                })

            # Always append the 'Add New' option
            rows.append({
                "id": "addr_new",
                "title": "➕ Add New Address",
                "description": "Enter a new delivery address"
            })
            self._send_address_list(session, rows)
        else:
            session.sudo().write({'step': 'address'})
            session.send_text(
                "Almost done! Please reply with your *Delivery Address* using EXACTLY this format separated by commas:\n\n"
                "🏠 *House Number, Street Name, City, Zip Code, Country*"
            )
    # old
    @http.route("/whatsapp/webhook", type="http", auth="public", methods=["GET"], csrf=False)
    def verify_webhook(self, **kwargs):
        mode = kwargs.get("hub.mode")
        token = kwargs.get("hub.verify_token")
        challenge = kwargs.get("hub.challenge")

        configured_token = request.env['ir.config_parameter'].sudo().get_param(
            'whatsapp_order.verify_token'
        )

        if mode == "subscribe" and token == configured_token:
            _logger.info("WEBHOOK VERIFIED BY META")
            return request.make_response(challenge, headers=[('Content-Type', 'text/plain')])

        return request.make_response("Forbidden", status=403)

    # 2. Incoming Messages Endpoint (POST)
    @http.route("/whatsapp/webhook", type="json", auth="public", methods=["POST"], csrf=False)
    def handle_messages(self, **kwargs):
        body = request.jsonrequest

        if not body or body.get("object") != "whatsapp_business_account":
            return {}

        try:
            entry = body["entry"][0]["changes"][0]["value"]
            if "messages" not in entry:
                return {}

            message = entry["messages"][0]
            phone = message["from"]
            msg_type = message["type"]

            contact_name = "Customer"
            try:
                contact_name = entry["contacts"][0]["profile"]["name"]
            except (KeyError, IndexError):
                pass

            clean_text = ""
            selected_product_title = None
            button_reply_id = None
            list_reply_id = None

            if msg_type == "text":
                clean_text = message["text"]["body"].lower().strip()
            elif msg_type == "interactive":
                itype = message["interactive"]["type"]
                if itype == "list_reply":
                    selected_product_title = message["interactive"]["list_reply"]["title"]
                    list_reply_id = message["interactive"]["list_reply"].get("id")  
                    clean_text = selected_product_title.lower()
                elif itype == "button_reply":
                    button_reply_id = message["interactive"]["button_reply"]["id"]
                    clean_text = message["interactive"]["button_reply"]["title"].lower()

            env = request.env
            session = env['whatsapp.session'].sudo().search([('phone', '=', phone)], limit=1)

            is_hard_reset = clean_text in {"menu", "cancel", "reset", "start"}
            is_greeting = clean_text in {"hi", "hello", "hii", "hey"}

            # 1. Initialize or Hard Reset
            if not session or is_hard_reset:
                if not session:
                    session = env['whatsapp.session'].sudo().create(
                        {'phone': phone, 'customer_name': contact_name})
                else:
                    session.sudo().write({'step': 'start', 'cart_data': '[]'})
                step = "start"
                cart = []

            # 2. Handle accidental "hi" mid-order
            elif is_greeting:
                cart = json.loads(session.cart_data or '[]')
                step = session.step

                if cart and step in ["confirm", "email", "cart_options", "product", "waiting_for_catalog"]:
                    session.sudo().write({'step': 'cart_options'})
                    cart_summary, total = self._format_cart(cart, env)

                    session.send_buttons(
                        f"👋 Welcome back! You are currently in the middle of an order.\n\n🛒 *Your Saved Cart:*\n{cart_summary}\n\nWhat would you like to do?",
                        [
                            {"id": "checkout_now", "title": "💳 Checkout"},
                            {"id": "add_more", "title": "➕ Add More"},
                            {"id": "clear_cart", "title": "🗑️ Cancel Order"}
                        ]
                    )
                    return {}
                else:
                    session.sudo().write({'step': 'start'})
                    step = "start"

            # 3. NORMAL FLOW
            else:
                step = session.step
                cart = json.loads(session.cart_data or '[]')

            # =================================================================
            # STEP 1: THE MAIN MENU
            # =================================================================
            if step == "start":
                session.sudo().write({'step': 'main_menu'})
                session.send_buttons(
                    f"👋 Hello {contact_name}!\nWelcome to our store. How can we help you today?",
                    [
                        {"id": "menu_shop", "title": "🛍️ Shop Now"},
                        {"id": "menu_contact", "title": "📞 Contact Us"},
                        {"id": "menu_cart", "title": "🛒 View Cart"},
                    ]
                )
                return {}

            # =================================================================
            # STEP 2: PROCESSING MAIN MENU SELECTION
            # =================================================================
            elif step == "main_menu":
                if button_reply_id == "menu_shop":
                    categories = env["product.public.category"].sudo().search_read(
                        [], ["id", "name"], limit=10
                    )
                    if not categories:
                        session.send_text("⚠️ No categories available right now.")
                        return {}

                    session.sudo().write({'step': 'category'})
                    session.send_category_list(categories)

                elif button_reply_id == "menu_profile":
                    partner = env['res.partner'].sudo().search([('phone', '=', phone)], limit=1)
                    name = partner.name if partner else (session.customer_name or "Not set")
                    email = partner.email if partner else (session.customer_email or "Not set")
                    address = partner.street if partner else (session.customer_address or "Not set")

                    profile_text = (
                        "👤 *YOUR PROFILE*\n"
                        "━━━━━━━━━━━━━━━━━━━━━\n"
                        f"📛 *Name:* {name}\n"
                        f"📱 *Phone:* {phone}\n"
                        f"📧 *Email:* {email}\n"
                        f"🏠 *Address:* {address}\n"
                        "━━━━━━━━━━━━━━━━━━━━━\n"
                        "What would you like to update?"
                    )

                    session.sudo().write({'step': 'profile_options'})
                    session.send_buttons(
                        profile_text,
                        [
                            {"id": "edit_name", "title": "📛 Edit Name"},
                            {"id": "edit_email", "title": "📧 Edit Email"},
                            {"id": "edit_address", "title": "🏠 Edit Address"}
                        ]
                    )
                    return {}

                elif button_reply_id == "menu_cart":
                    if not cart:
                        session.sudo().write({'step': 'main_menu'})
                        session.send_buttons(
                            "🛒 Your cart is currently empty.\n\nTap the button below to explore our catalog and start shopping!",
                            [{"id": "menu_shop", "title": "🛍️ Shop Now"}]
                        )
                        return {}
                    else:
                        session.sudo().write({'step': 'cart_options'})
                        cart_summary, total = self._format_cart(cart, env)
                        session.send_buttons(
                            f"🛒 *Your Current Cart:*\n{cart_summary}\n\nWhat would you like to do?",
                            [
                                {"id": "checkout_now", "title": "💳 Checkout"},
                                {"id": "add_more", "title": "➕ Add More"},
                                {"id": "clear_cart", "title": "🗑️ Cancel"}
                            ]
                        )
                elif button_reply_id == "menu_contact":

                    # Fetch the custom Contact URL from settings

                    contact_url = env['ir.config_parameter'].sudo().get_param('whatsapp_order.contact_url')

                    # Fallback just in case the admin leaves it blank

                    if not contact_url:
                        base_url = env['ir.config_parameter'].sudo().get_param('whatsapp_order.public_url') or env[
                            'ir.config_parameter'].sudo().get_param('web.base.url', '')

                        contact_url = f"{base_url.rstrip('/')}/contactus"

                    # Send the Contact URL

                    session.send_text(
                        f"📞 You can reach out to our team directly through our Contact Form here:\n{contact_url}")

                    # Keep the user in the main menu and show the remaining options

                    session.sudo().write({'step': 'main_menu'})

                    session.send_buttons(

                        "What else would you like to do?",

                        [

                            {"id": "menu_shop", "title": "🛍️ Shop Now"},

                            {"id": "menu_cart", "title": "🛒 View Cart"}

                        ]

                    )

                    return {}
                else:
                    session.send_text("Please use the buttons provided, or type *menu* to restart.")

            # //
                    # contact us logic

                    # =================================================================
                    # STEP 2.5: CATEGORY SELECTION
                    # =================================================================
            elif step == "category":
                    cat_id = None

                    # Check if they clicked the list item (looks for the "cat_X" ID we set earlier)
                    if list_reply_id and list_reply_id.startswith("cat_"):
                        cat_id = int(list_reply_id.split("_")[1])
                    else:
                        # Fallback: if they typed the category name manually
                        category = env["product.public.category"].sudo().search([('name', '=ilike', clean_text)],
                                                                                limit=1)
                        if category:
                            cat_id = category.id


                    if cat_id:
                        # Search for Templates instead of Products to group variants
                        templates = env["product.template"].sudo().search_read(
                            [("sale_ok", "=", True), ("active", "=", True), ("public_categ_ids", "in", [cat_id])],
                            ["id", "name", "list_price", "product_variant_count"], limit=10
                        )
                        # Use a modified list sender that handles template IDs
                        session.sudo().write({'step': 'select_template'})
                        session.send_interactive_list(templates)  # Ensure IDs are prefixed if needed
                    else:
                        session.send_text("❌ Please select a valid category from the list, or type *menu* to restart.")
                    return {}
            # =================================================================
            # STEP 3: ODOO PRODUCT SELECTION (The Fallback Flow)
            # =================================================================
            elif step == "product":
                if button_reply_id == "add_more":
                    # CHANGE: Query categories instead of products
                    categories = env["product.public.category"].sudo().search_read(
                        [], ["id", "name"], limit=10
                    )
                    session.sudo().write({'step': 'category'})
                    session.send_category_list(categories)
                    return {}

                if button_reply_id == "clear_cart":
                    session.sudo().write({'step': 'start', 'cart_data': '[]'})
                    session.send_text("🗑️ Your cart has been cleared. Type *menu* to start over.")
                    return {}

                if button_reply_id == "checkout":
                    if not cart:
                        session.send_text("🛒 Your cart is empty.")
                        return {}

                    if not session.customer_email:
                        session.sudo().write({'step': 'email'})
                        session.send_text("Great! What is your email address for the receipt? (Or reply 'skip')")
                    elif not session.customer_address:
                        session.sudo().write({'step': 'address'})
                        session.send_text(
                            "Almost done! Please reply with your *Delivery Address* using EXACTLY this format separated by commas:\n\n"
                            "🏠 *House Number, Street Name, City, Zip Code, Country*"
                        )
                    else:
                        session.sudo().write({'step': 'confirm'})
                        cart_summary, total = self._format_cart(cart, env)
                        session.send_buttons(
                            f"📋 *Order Summary:*\n{cart_summary}\n\n📍 *Deliver to:*\n{session.customer_address}\n\nConfirm your order?",
                            [{"id": "confirm_yes", "title": "✅ Confirm"}, {"id": "confirm_no", "title": "❌ Cancel"}]
                        )
                    return {}

                # Handle actual product selection from the list
                selected = None

                # 1. PRIMARY: Match securely using the hidden ID from the list
                if list_reply_id and list_reply_id.isdigit():
                    # FIX: Removed sale_ok=True. Variants inherit this from templates,
                    # so strictly searching it on product.product can fail in Odoo.
                    selected_record = env["product.product"].sudo().search_read(
                        [("id", "=", int(list_reply_id))],
                        ["id", "display_name", "list_price"], limit=1
                    )
                    if selected_record:
                        selected = selected_record[0]
                        selected['name'] = selected['display_name']

                        # 2. FALLBACK: If they manually typed the product name instead of clicking the list
                if not selected and clean_text:
                    products = env["product.product"].sudo().search_read(
                        [("sale_ok", "=", True), ("active", "=", True)],
                        ["id", "display_name", "list_price"]
                    )
                    selected = next(
                        (p for p in products if str(p["display_name"]).lower() == clean_text),
                        None
                    )
                    if selected:
                        selected['name'] = selected['display_name']

                # 3. Process the Selection
                if selected:
                    # FIX: Route the user to the Quantity step instead of adding directly to cart!
                    session.sudo().write({
                        'step': 'awaiting_quantity',
                        'selected_variant_id': selected['id']
                    })
                    session.ask_for_quantity(selected['name'])
                else:
                    session.send_text("❌ Please select a valid product from the list, or type *menu* to restart.")
                return {}


            # =================================================================
            # STEP 5: CART OPTIONS & CHECKOUT (From Main Menu -> View Cart)
            # =================================================================
            elif step == "cart_options":
                if button_reply_id == "clear_cart":
                    session.sudo().write({'step': 'start', 'cart_data': '[]'})
                    session.send_text("🗑️ Your cart has been cleared. Type *menu* to see options again.")


                elif button_reply_id == "add_more":

                    # CHANGE: Query categories instead of products

                    categories = env["product.public.category"].sudo().search_read(

                        [], ["id", "name"], limit=10

                    )

                    session.sudo().write({'step': 'category'})  # Change step to category

                    session.send_category_list(categories)

                    return {}

                elif button_reply_id == "checkout_now":
                    if not session.customer_email:
                        session.sudo().write({'step': 'email'})
                        session.send_text("Great! What is your email address for the receipt? (Or reply 'skip')")
                    elif not session.customer_address:
                        session.sudo().write({'step': 'address'})
                        session.send_text(
                            "Almost done! Please type your full *Delivery Address* (including City and ZIP code).")
                    else:
                        session.sudo().write({'step': 'confirm'})
                        cart_summary, total = self._format_cart(cart, env)
                        session.send_buttons(
                            f"📋 *Order Summary:*\n{cart_summary}\n\n📍 *Deliver to:*\n{session.customer_address}\n\nConfirm your order?",
                            [{"id": "confirm_yes", "title": "✅ Confirm"}, {"id": "confirm_no", "title": "❌ Cancel"}]
                        )
                else:
                    session.send_text("Please select an option or type *menu* to return to the main menu.")

                    # =================================================================
                    # TEMPLATE SELECTION (Variant Check)
                    # =================================================================
            elif step == "select_template":
                    template_id = None

                    # 1. Safely check if they clicked the list
                    if list_reply_id and list_reply_id.isdigit():
                        template_id = int(list_reply_id)
                    # 2. Fallback: Check if they manually typed the product name
                    else:
                        found_template = env['product.template'].sudo().search([('name', '=ilike', clean_text)],
                                                                               limit=1)
                        if found_template:
                            template_id = found_template.id

                    # 3. If we still don't have an ID, reject the input gracefully
                    if not template_id:
                        session.send_text("❌ Please select a valid product from the list, or type *menu* to restart.")
                        return {}

                    # 4. Process the Template
                    template = env['product.template'].sudo().browse(template_id)

                    if template.product_variant_count > 1:
                        # Show specific variants (e.g., Size, Color)
                        variants = template.product_variant_ids.sudo().read(["id", "display_name", "list_price"])

                        # Format the dictionary so your send_variant_list method can read it
                        formatted_variants = [
                            {"id": v["id"], "name": v["display_name"], "list_price": v["list_price"]}
                            for v in variants
                        ]

                        session.sudo().write({'step': 'product'})
                        session.send_variant_list(formatted_variants, template.name)
                    else:
                        # Only one variant, skip directly to asking for quantity
                        variant = template.product_variant_ids[0]
                        session.sudo().write({
                            'step': 'awaiting_quantity',
                            'selected_variant_id': variant.id
                        })
                        session.ask_for_quantity(variant.display_name)

                    return {}

                    # =================================================================

                    # QUANTITY SELECTION

                    # =================================================================

            elif step == "awaiting_quantity":

                    qty_text = button_reply_id.replace('qty_', '') if button_reply_id else clean_text

                    try:

                        qty = float(qty_text)

                        if qty <= 0: raise ValueError()


                    except:

                        session.send_text("⚠️ Please enter a valid number greater than 0.")

                        return {}

                    # Get the variant ID we saved in the previous step

                    variant_id = session.selected_variant_id.id

                    variant = env['product.product'].sudo().browse(variant_id)

                    # Add to cart with the specified quantity

                    cart = self._add_to_cart_with_qty(cart, variant, qty)

                    session.sudo().write({'cart_data': json.dumps(cart), 'step': 'product'})

                    # --- FIXED SUMMARY LOGIC ---

                    cart_summary, total = self._format_cart(cart, env)

                    total_items = sum(item['quantity'] for item in cart)

                    session.send_text(f"✅ Added {qty} x *{variant.display_name}* to cart.")

                    session.send_buttons(

                        f"🛒 *Your Cart ({total_items} items)*\n\n{cart_summary}",

                        [

                            {"id": "checkout", "title": "💳 Checkout"},

                            {"id": "add_more", "title": "➕ Add More"},

                            {"id": "clear_cart", "title": "🗑️ Clear Cart"}

                        ]

                    )

                    return {}


            # STEP 6, 7 & 8: EMAIL, ADDRESS, AND CONFIRM
            # =================================================================
            elif step == "email":
                email = "" if clean_text in {"skip", "no"} else message["text"]["body"].strip()
                session.sudo().write({'step': 'address', 'customer_email': email})

                session.send_text(
                    "Almost done! Please reply with your *Delivery Address* using EXACTLY this format separated by commas:\n\n"
                    "🏠 *House Number, Street Name, City, Zip Code, Country*\n\n"
                    "Example: *12B, Rose Villa, Mumbai, 400001, India*"
                )

            elif step == "address":
                address = message["text"]["body"].strip()
                session.sudo().write({'step': 'confirm', 'customer_address': address})

                cart_summary, total = self._format_cart(cart, env)
                session.send_buttons(
                    f"📋 *Final Order:*\n{cart_summary}\n\n📍 *Deliver to:*\n{address}\n\nIs everything correct?",
                    [{"id": "confirm_yes", "title": "✅ Confirm"}, {"id": "confirm_no", "title": "❌ Cancel"}]
                )

            elif step == "confirm":
                if button_reply_id == "confirm_no" or clean_text == "cancel":
                    session.sudo().write({'step': 'start', 'cart_data': '[]'})
                    session.send_text("🚫 Order cancelled. Send *menu* to start again.")
                elif button_reply_id == "confirm_yes" or clean_text == "confirm":
                    session.send_text("⏳ Processing your order...")

                    result = env['sale.order'].sudo().create_from_whatsapp(
                        phone=phone,
                        cart=cart,
                        customer_name=session.customer_name,
                        customer_email=session.customer_email,
                        customer_address=session.customer_address
                    )

                    session.sudo().write({'step': 'start', 'cart_data': '[]'})

                    if "error" in result:
                        session.send_text(f"❌ Error: {result['error']}")
                    else:
                        cart_summary, total = self._format_cart(cart, env)
                        session.send_text(
                            f"🎉 *Order Confirmed!*\n\n{cart_summary}\n\n💳 Pay securely here:\n{result.get('payment_link')}"
                        )


            # =================================================================
            # STEP 9: PROFILE EDITING SELECTION
            # =================================================================
            elif step == "profile_options":
                if button_reply_id == "edit_name":
                    session.sudo().write({'step': 'awaiting_name'})
                    session.send_text("Please type your full name:")
                elif button_reply_id == "edit_email":
                    session.sudo().write({'step': 'awaiting_email'})
                    session.send_text("Please type your new email address:")
                elif button_reply_id == "edit_address":
                    session.sudo().write({'step': 'awaiting_address'})
                    session.send_text(
                        "Please reply with your new *Delivery Address* using this format separated by commas:\n\n"
                        "🏠 *House Number, Street Name, City, Zip Code, Country*"
                    )
                else:
                    session.send_text("Please select an option or type *menu*.")

            # =================================================================
            # STEP 10: SAVING THE PROFILE DATA
            # =================================================================
            elif step in ["awaiting_name", "awaiting_email", "awaiting_address"]:
                new_value = message["text"]["body"].strip()
                partner = env['res.partner'].sudo().search([('phone', '=', phone)], limit=1)

                if step == "awaiting_name":
                    session.sudo().write({'customer_name': new_value, 'step': 'start'})
                    if partner:
                        partner.sudo().write({'name': new_value})
                    session.send_text(f"✅ Name updated to *{new_value}*.\nType *menu* to return to the main menu.")

                elif step == "awaiting_email":
                    session.sudo().write({'customer_email': new_value, 'step': 'start'})
                    if partner:
                        partner.sudo().write({'email': new_value})
                    session.send_text(f"✅ Email updated to *{new_value}*.\nType *menu* to return to the main menu.")

                elif step == "awaiting_address":
                    session.sudo().write({'customer_address': new_value, 'step': 'start'})
                    if partner:
                        partner.sudo().write({'street': new_value})
                    session.send_text(f"✅ Address updated.\nType *menu* to return to the main menu.")

            return {}

        except Exception as e:
            _logger.error(f"[WEBHOOK PARSING ERROR] {e}", exc_info=True)
            return {}