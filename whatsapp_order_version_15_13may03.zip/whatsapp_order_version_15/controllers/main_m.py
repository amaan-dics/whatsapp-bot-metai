import json
import logging
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class WhatsAppController(http.Controller):

    def _add_to_cart(self, cart, product):
        """Add product to cart or increment quantity if already present"""
        existing = next((item for item in cart if item.get('product_id') == product['id']), None)
        if existing:
            existing['quantity'] += 1
        else:
            cart.append({
                'product_id': product['id'],
                'product_name': product['name'],
                'quantity': 1,
                'price': product.get('list_price', 0.0),
            })
        return cart

    def _format_cart(self, cart, env):
        """Return formatted cart text with professional receipt layout"""
        if not cart:
            return "_(empty)_", 0.0

        lines = []
        total = 0.0
        currency = env.company.currency_id.symbol or '₹'

        # 1. Professional Header
        lines.append("🛍️ *YOUR SHOPPING CART*")
        lines.append("━━━━━━━━━━━━━━━━━━━━━")

        # 2. Structured Item List
        for item in cart:
            qty = item.get('quantity', 1)
            price = item.get('price', 0.0)

            if not price and item.get('product_id'):
                product = env['product.product'].sudo().browse(item['product_id'])
                price = product.list_price if product else 0.0

            subtotal = price * qty
            total += subtotal

            # Formats like:
            # 📦 *Product Name*
            #    └ 2 x ₹50.00 = ₹100.00
            lines.append(f"📦 *{item['product_name']}*")
            lines.append(f"   └  {qty} x {currency}{price:.2f} = *{currency}{subtotal:.2f}*")
            lines.append("")  # Adds a blank line between items for breathing room

        # 3. Professional Footer
        lines.append("━━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"🧾 *TOTAL DUE:* {currency}{total:.2f}")

        return "\n".join(lines), total

    @http.route("/whatsapp/webhook", type="http", auth="public", methods=["GET"], csrf=False)
    def verify_webhook(self, **kwargs):
        mode = kwargs.get("hub.mode")
        token = kwargs.get("hub.verify_token")
        challenge = kwargs.get("hub.challenge")

        configured_token = request.env['ir.config_parameter'].sudo().get_param(
            'whatsapp_order.verify_token'
        )

        if mode == "subscribe" and token == configured_token:
            _logger.info("WEBHOOK VERIFIED BY META")
            return request.make_response(challenge, headers=[('Content-Type', 'text/plain')])

        return request.make_response("Forbidden", status=403)

    # 2. Incoming Messages Endpoint (POST)
    @http.route("/whatsapp/webhook", type="json", auth="public", methods=["POST"], csrf=False)
    def handle_messages(self, **kwargs):
        body = request.jsonrequest

        if not body or body.get("object") != "whatsapp_business_account":
            return {}

        try:
            entry = body["entry"][0]["changes"][0]["value"]
            if "messages" not in entry:
                return {}

            message = entry["messages"][0]
            phone = message["from"]
            msg_type = message["type"]

            contact_name = "Customer"
            try:
                contact_name = entry["contacts"][0]["profile"]["name"]
            except (KeyError, IndexError):
                pass

            clean_text = ""
            selected_product_title = None
            button_reply_id = None

            if msg_type == "text":
                clean_text = message["text"]["body"].lower().strip()
            elif msg_type == "interactive":
                itype = message["interactive"]["type"]
                if itype == "list_reply":
                    selected_product_title = message["interactive"]["list_reply"]["title"]
                    clean_text = selected_product_title.lower()
                elif itype == "button_reply":
                    button_reply_id = message["interactive"]["button_reply"]["id"]
                    clean_text = message["interactive"]["button_reply"]["title"].lower()


            env = request.env
            session = env['whatsapp.session'].sudo().search([('phone', '=', phone)], limit=1)

            is_hard_reset = clean_text in {"menu", "cancel", "reset", "start"}
            is_greeting = clean_text in {"hi", "hello", "hii", "hey"}

            # 1. Initialize or Hard Reset
            if not session or is_hard_reset:
                if not session:
                    session = env['whatsapp.session'].sudo().create(
                        {'phone': phone, 'customer_name': contact_name})
                else:
                    session.sudo().write({'step': 'start', 'cart_data': '[]'})
                step = "start"
                cart = []

            # 2. Handle accidental "hi" mid-order
            elif is_greeting:
                cart = json.loads(session.cart_data or '[]')
                step = session.step

                if cart and step in ["confirm", "email", "cart_options", "product", "waiting_for_catalog"]:
                    # Intercept the greeting, show their cart, and give them the 3 action buttons
                    session.sudo().write({'step': 'cart_options'})
                    cart_summary, total = self._format_cart(cart, env)

                    session.send_buttons(
                        f"👋 Welcome back! You are currently in the middle of an order.\n\n🛒 *Your Saved Cart:*\n{cart_summary}\n\nWhat would you like to do?",
                        [
                            {"id": "checkout_now", "title": "💳 Checkout"},
                            {"id": "add_more", "title": "➕ Add More"},
                            {"id": "clear_cart", "title": "🗑️ Cancel Order"}
                        ]
                    )
                    return {}
                else:
                    # If cart is empty, "hi" safely acts as a reset to the main menu
                    session.sudo().write({'step': 'start'})
                    step = "start"

            # 3. NORMAL FLOW (This was the missing piece!)
            else:
                step = session.step
                cart = json.loads(session.cart_data or '[]')

            # =================================================================
            # STEP 1: THE MAIN MENU
            # =================================================================
            if step == "start":
                session.sudo().write({'step': 'main_menu'})
                session.send_buttons(
                    f"👋 Hello {contact_name}!\nWelcome to our store. How can we help you today?",
                    [
                        {"id": "menu_shop", "title": "🛍️ Shop Now"},
                        {"id": "menu_contact", "title": "📞 Contact Us"},
                        {"id": "menu_cart", "title": "🛒 View Cart"},

                    ]
                )
                return {}

            # =================================================================
            # STEP 2: PROCESSING MAIN MENU SELECTION
            # =================================================================
            elif step == "main_menu":
                if button_reply_id == "menu_shop":
                    # FALLBACK: Fetch up to 10 products directly from Odoo
                    products = env["product.product"].sudo().search_read(
                        [("sale_ok", "=", True), ("active", "=", True)],
                        ["id", "name", "list_price"], limit=10
                    )
                    if not products:
                        session.send_text("⚠️ No products available right now.")
                        return {}

                    # Update step to 'product' so the bot expects a list selection next
                    session.sudo().write({'step': 'product'})
                    session.send_interactive_list(products)



                elif button_reply_id == "menu_contact":

                    # Fetch the custom Contact URL from settings

                    contact_url = env['ir.config_parameter'].sudo().get_param('whatsapp_order.contact_url')

                    # Fallback just in case the admin leaves it blank

                    if not contact_url:
                        base_url = env['ir.config_parameter'].sudo().get_param('whatsapp_order.public_url') or env[
                            'ir.config_parameter'].sudo().get_param('web.base.url', '')

                        contact_url = f"{base_url.rstrip('/')}/contactus"

                    # Send the Contact URL

                    session.send_text(
                        f"📞 You can reach out to our team directly through our Contact Form here:\n{contact_url}")

                    # Keep the user in the main menu and show the remaining options

                    session.sudo().write({'step': 'main_menu'})

                    session.send_buttons(

                        "What else would you like to do?",

                        [

                            {"id": "menu_shop", "title": "🛍️ Shop Now"},

                            {"id": "menu_cart", "title": "🛒 View Cart"}

                        ]

                    )

                    return {}

                elif button_reply_id == "menu_profile":
                    # Fetch real-time data from Odoo
                    partner = env['res.partner'].sudo().search([('phone', '=', phone)], limit=1)

                    name = partner.name if partner else (session.customer_name or "Not set")
                    email = partner.email if partner else (session.customer_email or "Not set")
                    address = partner.street if partner else (session.customer_address or "Not set")

                    profile_text = (
                        "👤 *YOUR PROFILE*\n"
                        "━━━━━━━━━━━━━━━━━━━━━\n"
                        f"📛 *Name:* {name}\n"
                        f"📱 *Phone:* {phone}\n"
                        f"📧 *Email:* {email}\n"
                        f"🏠 *Address:* {address}\n"
                        "━━━━━━━━━━━━━━━━━━━━━\n"
                        "What would you like to update?"
                    )

                    # Move them to the profile options step
                    session.sudo().write({'step': 'profile_options'})
                    session.send_buttons(
                        profile_text,
                        [
                            {"id": "edit_name", "title": "📛 Edit Name"},
                            {"id": "edit_email", "title": "📧 Edit Email"},
                            {"id": "edit_address", "title": "🏠 Edit Address"}
                        ]
                    )
                    return {}

                elif button_reply_id == "menu_cart":

                    if not cart:

                        # Keep them in the main menu step so the "Shop Now" button works

                        session.sudo().write({'step': 'main_menu'})

                        session.send_buttons(

                            "🛒 Your cart is currently empty.\n\nTap the button below to explore our catalog and start shopping!",

                            [

                                {"id": "menu_shop", "title": "🛍️ Shop Now"},

                            ]

                        )

                        return {}

                    else:

                        session.sudo().write({'step': 'cart_options'})
                        cart_summary, total = self._format_cart(cart, env)
                        session.send_buttons(
                            f"🛒 *Your Current Cart:*\n{cart_summary}\n\nWhat would you like to do?",
                            [
                                {"id": "checkout_now", "title": "💳 Checkout"},
                                {"id": "add_more", "title": "➕ Add More"},  # <--- NEW BUTTON
                                {"id": "clear_cart", "title": "🗑️ Cancel"}
                            ]
                        )
                else:
                    session.send_text("Please use the buttons provided, or type *menu* to restart.")

            # =================================================================
            # STEP 3: ODOO PRODUCT SELECTION (The Fallback Flow)
            # =================================================================
            elif step == "product":
                if button_reply_id == "add_more":
                    products = env["product.product"].sudo().search_read(
                        [("sale_ok", "=", True), ("active", "=", True)],
                        ["id", "name", "list_price"], limit=10
                    )
                    session.send_interactive_list(products)
                    return {}

                if button_reply_id == "checkout":
                    if not cart:
                        session.send_text("🛒 Your cart is empty.")
                        return {}
                    session.sudo().write({'step': 'cart_options'})
                    cart_summary, total = self._format_cart(cart, env)
                    session.send_buttons(
                        f"🛒 *Your Current Cart:*\n{cart_summary}\n\nWhat would you like to do?",
                        [
                            {"id": "checkout_now", "title": "💳 Checkout"},
                            {"id": "add_more", "title": "➕ Add More"},  # <--- NEW BUTTON
                            {"id": "clear_cart", "title": "🗑️ Cancel"}
                        ]
                    )
                    return {}

                # Handle actual product selection from the list
                products = env["product.product"].sudo().search_read(
                    [("sale_ok", "=", True), ("active", "=", True)],
                    ["id", "name", "list_price"]
                )

                selected = next(
                    (p for p in products if
                     str(p["name"])[:24] == selected_product_title or
                     str(p["name"]).lower() == clean_text),
                    None
                )

                if selected:
                    cart = self._add_to_cart(cart, selected)
                    session.sudo().write({'cart_data': json.dumps(cart)})

                    cart_summary, total = self._format_cart(cart, env)
                    total_items = sum(item['quantity'] for item in cart)

                    session.send_text(f"✅ Added *{selected['name']}* to cart.")
                    session.send_buttons(
                        f"🛒 *Your Cart ({total_items} items)*\n\n{cart_summary}\n\nWhat next?",
                        [
                            {"id": "add_more", "title": "➕ Add More"},
                            {"id": "checkout", "title": "🛒 View Cart"}
                        ]
                    )
                else:
                    session.send_text("❌ Please select a valid product from the list, or type *menu* to restart.")

            # =================================================================
            # STEP 4: CUSTOMER SUPPORT FLOW
            # =================================================================
            elif step == "waiting_for_query":
                user_query = message["text"]["body"] if msg_type == "text" else "Sent a media file/voice note"
                _logger.info(f"🚨 NEW CUSTOMER TICKET from {phone} ({contact_name}): {user_query}")

                # 1. Safely try to create the CRM Lead
                try:
                    env['crm.lead'].sudo().create({
                        'name': f'WhatsApp Inquiry: {contact_name}',
                        'description': user_query,
                        'contact_name': contact_name,
                        'phone': phone
                    })
                except Exception as e:
                    _logger.error(f"⚠️ Could not create CRM Lead. Is the CRM app installed? Error: {e}")

                # 2. Reset the session
                session.sudo().write({'step': 'start'})

                # 3. ACTUALLY SEND THE REPLY (This was missing!)
                session.send_buttons(
                    "✅ Thank you! Your query has been safely registered.\n\nOur team will review it and contact you soon. What else can we help you with?",
                    [
                        {"id": "menu_shop", "title": "🛍️ Shop Now"},
                        {"id": "menu_cart", "title": "🛒 View Cart"}
                    ]
                )

            # =================================================================
            # STEP 5: CART OPTIONS & CHECKOUT
            # =================================================================
            elif step == "cart_options":
                if button_reply_id == "clear_cart":
                    session.sudo().write({'step': 'start', 'cart_data': '[]'})
                    session.send_text("🗑️ Your cart has been cleared. Type *menu* to see options again.")

                # --- NEW 'ADD MORE' LOGIC ---
                elif button_reply_id == "add_more":
                    products = env["product.product"].sudo().search_read(
                        [("sale_ok", "=", True), ("active", "=", True)],
                        ["id", "name", "list_price"], limit=10
                    )
                    session.sudo().write({'step': 'product'})
                    session.send_interactive_list(products)
                # ----------------------------

                elif button_reply_id == "checkout_now":

                    # 1. Check if we need the email

                    if not session.customer_email:

                        session.sudo().write({'step': 'email'})

                        session.send_text("Great! What is your email address for the receipt? (Or reply 'skip')")


                    # 2. Check if we need the address

                    elif not session.customer_address:

                        session.sudo().write({'step': 'address'})

                        session.send_text(
                            "Almost done! Please type your full *Delivery Address* (including City and ZIP code).")


                    # 3. If we have both, go straight to confirm

                    else:

                        session.sudo().write({'step': 'confirm'})

                        cart_summary, total = self._format_cart(cart, env)

                        session.send_buttons(

                            f"📋 *Order Summary:*\n{cart_summary}\n\n📍 *Deliver to:*\n{session.customer_address}\n\nConfirm your order?",

                            [{"id": "confirm_yes", "title": "✅ Confirm"}, {"id": "confirm_no", "title": "❌ Cancel"}]

                        )
                else:
                    session.send_text("Please select an option or type *menu* to return to the main menu.")

                    # =================================================================
                    # STEP 6, 7 & 8: EMAIL, ADDRESS, AND CONFIRM
                    # =================================================================
            elif step == "email":
                    # Save the email and ask for the address in a STRICT format
                    email = "" if clean_text in {"skip", "no"} else message["text"]["body"].strip()
                    session.sudo().write({'step': 'address', 'customer_email': email})

                    session.send_text(
                        "Almost done! Please reply with your *Delivery Address* using EXACTLY this format separated by commas:\n\n"
                        "🏠 *House Number, Street Name, City, Zip Code, Country*\n\n"
                        "Example: *12B, Rose Villa, Mumbai, 400001, India*"
                    )

            elif step == "address":
                # Save the address and show the final confirmation
                address = message["text"]["body"].strip()
                session.sudo().write({'step': 'confirm', 'customer_address': address})

                cart_summary, total = self._format_cart(cart, env)
                session.send_buttons(
                    f"📋 *Final Order:*\n{cart_summary}\n\n📍 *Deliver to:*\n{address}\n\nIs everything correct?",
                    [{"id": "confirm_yes", "title": "✅ Confirm"}, {"id": "confirm_no", "title": "❌ Cancel"}]
                )

            elif step == "confirm":
                if button_reply_id == "confirm_no" or clean_text == "cancel":
                    session.sudo().write({'step': 'start', 'cart_data': '[]'})
                    session.send_text("🚫 Order cancelled. Send *menu* to start again.")
                elif button_reply_id == "confirm_yes" or clean_text == "confirm":
                    session.send_text("⏳ Processing your order...")

                    # --- NOTICE: We are now passing the customer_address! ---
                    result = env['sale.order'].sudo().create_from_whatsapp(
                        phone=phone,
                        cart=cart,
                        customer_name=session.customer_name,
                        customer_email=session.customer_email,
                        customer_address=session.customer_address
                    )

                    session.sudo().write({'step': 'start', 'cart_data': '[]'})

                    if "error" in result:
                        session.send_text(f"❌ Error: {result['error']}")
                    else:
                        cart_summary, total = self._format_cart(cart, env)
                        session.send_text(
                            f"🎉 *Order Confirmed!*\n\n{cart_summary}\n\n💳 Pay securely here:\n{result.get('payment_link')}"
                        )
            # //
            # =================================================================
            # STEP 8: PROFILE EDITING SELECTION
            # =================================================================
            elif step == "profile_options":
                        if button_reply_id == "edit_name":
                            session.sudo().write({'step': 'awaiting_name'})
                            session.send_text("Please type your full name:")
                        elif button_reply_id == "edit_email":
                            session.sudo().write({'step': 'awaiting_email'})
                            session.send_text("Please type your new email address:")
                        elif button_reply_id == "edit_address":
                            session.sudo().write({'step': 'awaiting_address'})
                            session.send_text(
                                "Please reply with your new *Delivery Address* using this format separated by commas:\n\n"
                                "🏠 *House Number, Street Name, City, Zip Code, Country*"
                            )
                        else:
                            session.send_text("Please select an option or type *menu*.")

            # =================================================================
            # STEP 9: SAVING THE PROFILE DATA
            # =================================================================
            elif step in ["awaiting_name", "awaiting_email", "awaiting_address"]:
                    new_value = message["text"]["body"].strip()
                    partner = env['res.partner'].sudo().search([('phone', '=', phone)], limit=1)

                    # 1. Update Name
                    if step == "awaiting_name":
                        session.sudo().write({'customer_name': new_value, 'step': 'start'})
                        if partner:
                            partner.sudo().write({'name': new_value})
                        session.send_text(f"✅ Name updated to *{new_value}*.\nType *menu* to return to the main menu.")

                    # 2. Update Email
                    elif step == "awaiting_email":
                        session.sudo().write({'customer_email': new_value, 'step': 'start'})
                        if partner:
                            partner.sudo().write({'email': new_value})
                        session.send_text(f"✅ Email updated to *{new_value}*.\nType *menu* to return to the main menu.")

                    # 3. Update Address
                    elif step == "awaiting_address":
                        session.sudo().write({'customer_address': new_value, 'step': 'start'})
                        if partner:
                            # We save it to street here; your sale_order.py parser will handle it beautifully
                            # during the next checkout if they use commas!
                            partner.sudo().write({'street': new_value})
                        session.send_text(f"✅ Address updated.\nType *menu* to return to the main menu.")

            return {}

        except Exception as e:
            _logger.error(f"[WEBHOOK PARSING ERROR] {e}", exc_info=True)
            return {}